# background-generator
A gradient background generator using HTML, CSS and Vanilla JavaScript 
